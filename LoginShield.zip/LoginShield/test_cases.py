"""
test_cases.py - Predefined test cases for the in-app Test Case Laboratory.

Each case is executed through the real DFA (via analyzer.analyze_text). The
"actual" output and the PASS/FAIL verdict are computed at run time; nothing
here is hard-coded except the *expected* values defined by the specification.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import pandas as pd

from analyzer import (
    VERDICT_INVALID,
    VERDICT_NONE,
    VERDICT_SUSPICIOUS,
    analyze_text,
)


@dataclass(frozen=True)
class LabCase:
    number: int
    name: str
    sequence: str
    expected: str


@dataclass(frozen=True)
class LabResult:
    case: LabCase
    actual: str
    passed: bool


LAB_CASES: List[LabCase] = [
    LabCase(1, "Empty input", "", VERDICT_NONE),
    LabCase(2, "Single failure", "F", VERDICT_NONE),
    LabCase(3, "Three failures", "F F F", VERDICT_NONE),
    LabCase(4, "Four failures", "F F F F", VERDICT_SUSPICIOUS),
    LabCase(5, "Reset breaks the streak", "F F S F F", VERDICT_NONE),
    LabCase(6, "Pattern then success", "S F F F F S", VERDICT_SUSPICIOUS),
    LabCase(7, "Five failures", "F F F F F", VERDICT_SUSPICIOUS),
    LabCase(8, "Invalid symbol", "F F F X", VERDICT_INVALID),
]


def run_case(case: LabCase) -> LabResult:
    actual = analyze_text(case.sequence).verdict
    return LabResult(case, actual, actual == case.expected)


def run_all_cases(cases: List[LabCase] = None) -> List[LabResult]:
    return [run_case(c) for c in (cases if cases is not None else LAB_CASES)]


def pass_percentage(results: List[LabResult]) -> float:
    """Percentage of executed cases that passed (0.0 when nothing was run)."""
    if not results:
        return 0.0
    return 100.0 * sum(r.passed for r in results) / len(results)


def results_dataframe(results: List[LabResult]) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "Test Case": [f"{r.case.number}. {r.case.name}" for r in results],
            "Input Sequence": [r.case.sequence or "(empty)" for r in results],
            "Expected Output": [r.case.expected for r in results],
            "Actual Output": [r.actual for r in results],
            "Result": ["PASS" if r.passed else "FAIL" for r in results],
        }
    )


def definitions_dataframe() -> pd.DataFrame:
    """Case definitions only (before anything has been executed)."""
    return pd.DataFrame(
        {
            "Test Case": [f"{c.number}. {c.name}" for c in LAB_CASES],
            "Input Sequence": [c.sequence or "(empty)" for c in LAB_CASES],
            "Expected Output": [c.expected for c in LAB_CASES],
        }
    )
