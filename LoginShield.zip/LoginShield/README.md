# 🛡️ LoginShield — DFA-Powered Login Threat Pattern Detection

**Project title:** DFA-Based Detection of Suspicious Brute-Force Login Patterns
**Course:** Formal Language and Automata (FLA)

---

## 1. Project introduction

LoginShield is a login-security monitoring dashboard whose detection engine is a
**Deterministic Finite Automaton (DFA)**. A stream of login events (`F` = failed,
`S` = successful) is fed to the automaton one symbol at a time; when the
automaton reaches its accepting state `q4`, the system raises a *suspicious
brute-force pattern* alert. The web interface is built with Streamlit, Pandas
and Plotly, while the DFA itself uses only the Python standard library.

## 2. Real-world problem statement

Brute-force and credential-stuffing attacks show up in authentication logs as
long runs of failed logins. Security teams need a detector that is
**predictable, explainable and cheap to run** on a stream of events. A DFA has
constant memory (five states), reads each event once, and every alert can be
explained by the exact path of states that led to it — unlike a black-box model.

## 3. Project objectives

1. Model "four or more consecutive failed logins" as a DFA and implement it exactly.
2. Run **all** detection through the state-transition function (no counters/heuristics/ML).
3. Distinguish *"a pattern occurred"* from *"the current state"* (an alert is remembered after a success resets the DFA).
4. Provide a SOC-style dashboard: manual analyzer, state diagram, transition history, CSV upload/export, test laboratory and plain-English explanations.
5. Verify correctness with automated tests.

## 4. FLA mathematical model

```
M = (Q, Σ, δ, q0, F)

Q  = { q0, q1, q2, q3, q4 }
Σ  = { F, S }           F = failed login, S = successful login
q0 = initial state
F  = { q4 }             accepting state (note: the set F of final states, not the symbol F)
δ  : Q × Σ → Q          see the table below
```

## 5. DFA state explanation

| State | Meaning | Category |
|-------|---------|----------|
| q0 | No consecutive failures | Normal |
| q1 | One consecutive failure | Normal |
| q2 | Two consecutive failures | Warning |
| q3 | Three consecutive failures | Warning |
| q4 | Four or more consecutive failures | **Suspicious (accepting)** |

## 6. Transition table

| Current State | F  | S  |
|---------------|----|----|
| → q0          | q1 | q0 |
| q1            | q2 | q0 |
| q2            | q3 | q0 |
| q3            | q4 | q0 |
| *q4 (accepting)* | q4 | q0 |

```
          F        F        F        F        F (loop)
   → q0 ───▶ q1 ───▶ q2 ───▶ q3 ───▶ (q4) ◀──╮
     ▲╲        │        │        │      │ ╰───╯
     │ S (loop)│ S      │ S      │ S    │ S
     ╰─────────┴────────┴────────┴──────╯   (every S returns to q0)
```

The Plotly diagram in the app is **generated from this same table** in code
(`diagram.compute_edges()`), and a unit test checks that its 10 edges equal the
specified table, so the picture cannot drift from the model.

## 7. System architecture

```
 ┌───────────────┐   text / CSV    ┌───────────────┐
 │   app.py      │ ──────────────▶ │ analyzer.py   │  parse → DFA run → history + explanation
 │ (Streamlit UI)│ ◀────────────── │ csv_handler.py│  validate file → analyze → report
 │ diagram.py    │   results       │ test_cases.py │  predefined cases → analyzer
 └───────────────┘                 └──────┬────────┘
                                          ▼
                                   ┌───────────────┐
                                   │ dfa_engine.py │  states, Σ, δ, run(): the ONLY detection logic
                                   └───────────────┘
```

* **dfa_engine.py** – `DFA` class (validates totality of δ), the exact LoginShield table, `run()` returning every transition, the final state, whether q4 was *ever* visited and the steps at which q4 was *entered*.
* **analyzer.py** – tokenises input, wraps the DFA run, builds the transition history table and explanations, assigns the verdict (`SUSPICIOUS` / `NO PATTERN` / `INVALID INPUT`).
* **csv_handler.py** – reads and validates uploads, processes events in file order, exports the report and a summary.
* **test_cases.py** – the 8 predefined lab cases; actual outputs and the pass percentage are computed at run time.
* **diagram.py** – DFA diagram (extra module added to keep `app.py` focused on the UI).
* **app.py** – the Streamlit dashboard.

## 8. Project folder structure

```
LoginShield/
├── app.py
├── dfa_engine.py
├── analyzer.py
├── csv_handler.py
├── test_cases.py
├── diagram.py                # DFA diagram (Plotly)
├── requirements.txt
├── README.md
├── pytest.ini
├── .gitignore
├── .streamlit/config.toml    # dark theme
├── assets/
│   └── style.css
├── tests/
│   └── test_dfa.py
└── sample_data/
    └── login_events.csv
```

## 9. Technologies used

Python 3 · Streamlit (UI) · Pandas (tables, CSV) · Plotly (charts and DFA diagram) · Python standard library (DFA).

## 10. Installation (Windows, VS Code or PyCharm)

```bat
cd LoginShield
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 11. How to run

```bat
streamlit run app.py
```

The dashboard opens at <http://localhost:8501>. Tabs: **Dashboard**, **Analyzer**,
**DFA Diagram**, **CSV Upload**, **Test Lab**.

## 12. Sample inputs and outputs

| Input | State path | Pattern occurred | Final state | Verdict |
|-------|-----------|------------------|-------------|---------|
| *(empty)* | q0 | NO | q0 | NO PATTERN |
| `F F F` | q0→q1→q2→q3 | NO | q3 | NO PATTERN |
| `F F F F` | q0→q1→q2→q3→q4 | YES | q4 | SUSPICIOUS |
| `F F S F F` | q0→q1→q2→q0→q1→q2 | NO | q2 | NO PATTERN |
| `F F F F S` | q0→q1→q2→q3→q4→q0 | **YES** | **q0** | SUSPICIOUS |
| `S F F F F S` | q0→q0→q1→q2→q3→q4→q0 | YES | q0 | SUSPICIOUS |
| `F F F F F` | q0→q1→q2→q3→q4→q4 | YES | q4 | SUSPICIOUS |
| `F F F X` | — | — | — | INVALID INPUT |

Example explanation for `F F F F`: *"Four or more consecutive failed login
attempts were detected. The DFA path was q0 → q1 → q2 → q3 → q4, entering the
accepting state q4 at step 4."*

`F F F F S`: *"…The suspicious pattern was detected before the successful login
reset the current DFA state, so the final state is q0 … even though an alert
occurred earlier in the sequence."*

Input is case-insensitive and may use spaces, commas or compact form (`FFFFS`).

**CSV format** (`sample_data/login_events.csv`):

```
event_id,event_type
1,F
2,F
3,S
4,F
```

The CSV tab validates the header and values, shows warnings (extra columns,
duplicate ids), and offers downloads of the per-event report
(`step,event_id,event_type,previous_state,next_state,status,alert_triggered`) and a summary.

## 13. Testing

```bat
python -m unittest discover -s tests -v
:: or, if pytest is installed:
python -m pytest -v
```

The suite (29 tests) covers every one of the 10 transitions, four and five-plus
consecutive failures, reset by success, an alert followed by success, multiple
alerts, the empty sequence, invalid symbols, CSV validation (missing columns,
bad/blank values, empty files, BOM, extra columns, duplicates), the lab cases
and pass-rate calculation, and diagram/table consistency. It also brute-force
checks all strings up to length 8 against the regular-language characterisation
below. The in-app **Test Lab** tab runs the 8 specified cases and calculates the
pass percentage from real results.

## 14. How the project demonstrates the FLA concepts

* **Deterministic Finite Automata** – M = (Q, Σ, δ, q0, F) is implemented literally; δ is *total* (every state has exactly one move per symbol; `DFA._validate` enforces this) and deterministic (a dictionary lookup gives one next state).
* **Alphabet and states** – Σ = {F, S}; any other symbol is rejected (`InvalidSymbolError`). The five states encode the only memory needed: the current failure streak capped at 4.
* **Transition function** – δ(q, a) is `TRANSITION_TABLE[q][a]`; each row in the history table is one application of δ.
* **Regular languages** – Let L = Σ\* FFFF Σ\* (strings containing four consecutive F's). It is regular because a DFA recognises it. Under *final-state* acceptance, the automaton given accepts L_end = Σ\* FFFF (strings that **end** with at least four F's). The "alert occurred" feature — remembering that q4 was visited — is exactly membership in L, computed by tracking whether any visited state was accepting. (Making q4 absorbing would give a pure DFA for L, but the specification requires S to reset to q0 so the live state stays meaningful.)
* **Language acceptance** – `DFA.accepts()` is classical acceptance (ends in q4); `DFA.contains_pattern()` is "visited q4". The UI shows both: *Final state* versus *Suspicious pattern occurred*.
* **Decidability** – Membership in a regular language is decidable: the DFA halts after exactly |w| steps on every input w and answers accept/reject, so the question "does this login sequence contain a brute-force pattern?" is decidable in linear time and constant space.

## 15. Limitations

* Detects only *consecutive* failures; slow attacks spread over time or across accounts are not detected.
* The threshold (4) is fixed by the specification; no timestamps, usernames or IP addresses are modelled.
* Dashboard counters live in the browser session and reset when it is closed or the page is reloaded.
* Events are read from a manual string or CSV, not from a live log stream.

## 16. Future enhancements

* Configurable threshold (generate the DFA with *k+1* states).
* Per-user / per-IP automata and time windows.
* Live log tailing and alert notifications (email/Slack).
* Minimisation and NFA→DFA demonstrations for teaching.
* Persistent storage of analyses.

## 17. Uploading to GitHub

```bat
cd LoginShield
git init
git add .
git commit -m "LoginShield: DFA-based brute-force login detection"
git branch -M main
git remote add origin https://github.com/<your-username>/LoginShield.git
git push -u origin main
```

Create the empty `LoginShield` repository on github.com first (no README/licence), then run the commands above.
