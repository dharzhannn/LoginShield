"""
diagram.py - DFA transition diagram for LoginShield (Plotly).

The edge list is generated directly from dfa_engine.TRANSITION_TABLE, so the
picture cannot drift from the mathematical model. Geometry (compute_edges) is
plain Python and testable without Plotly; build_figure imports Plotly lazily.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

from dfa_engine import (
    ACCEPTING_STATES,
    ALPHABET,
    LOGIN_DFA,
    START_STATE,
    STATE_CATEGORY,
    STATE_DESCRIPTIONS,
    STATES,
)

X_SPACING = 2.0
NODE_Y = 0.0

COLORS = {
    "Normal": "#2f81f7",
    "Warning": "#f5a524",
    "Suspicious": "#ff4d4f",
    "F": "#ff8a65",
    "S": "#34d399",
    "current": "#22d3ee",
    "text": "#e6edf7",
    "muted": "#8b9bb4",
}


def node_position(state: str) -> Tuple[float, float]:
    return (STATES.index(state) * X_SPACING, NODE_Y)


def _bezier(p0, c, p2, n=30) -> List[Tuple[float, float]]:
    pts = []
    for i in range(n + 1):
        t = i / n
        x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * c[0] + t ** 2 * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * c[1] + t ** 2 * p2[1]
        pts.append((x, y))
    return pts


def compute_edges() -> List[Dict]:
    """
    One edge per entry of the transition table (|Q| x |Sigma| = 10 edges).

    Each edge: source, symbol, target, kind (forward|back|loop), points, label_pos
    """
    edges = []
    for src in STATES:
        for symbol in ALPHABET:
            dst = LOGIN_DFA.transitions[src][symbol]
            si, di = STATES.index(src), STATES.index(dst)
            sx, sy = node_position(src)
            dx, dy = node_position(dst)

            if src == dst:  # self loop above the node
                cx, cy, r = sx, 0.78, 0.32
                pts = [
                    (cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a)))
                    for a in range(-60, 241, 8)
                ]
                kind, label = "loop", (cx, cy + r + 0.22)
            elif di == si + 1:  # straight forward arrow
                pts = [(sx + 0.38, sy), (dx - 0.38, dy)]
                kind, label = "forward", ((sx + dx) / 2, 0.28)
            else:  # curved arc below the line, going backwards
                span = si - di
                depth = 0.8 + 0.5 * span
                start = (sx, sy - 0.42)
                end = (dx + 0.06 * span, dy - 0.42)
                ctrl = ((sx + dx) / 2, -depth)
                pts = _bezier(start, ctrl, end)
                mid = pts[len(pts) // 2]
                kind, label = "back", (mid[0], mid[1] - 0.2)

            edges.append(
                {
                    "source": src,
                    "symbol": symbol,
                    "target": dst,
                    "kind": kind,
                    "points": pts,
                    "label_pos": label,
                }
            )
    return edges


def edge_set() -> set:
    """The set of (source, symbol, target) triples drawn in the diagram."""
    return {(e["source"], e["symbol"], e["target"]) for e in compute_edges()}


def build_figure(current_state: Optional[str] = None, height: int = 470):
    """Create the Plotly figure, optionally highlighting `current_state`."""
    import plotly.graph_objects as go

    fig = go.Figure()
    annotations = []

    # ---- edges -----------------------------------------------------------
    for e in compute_edges():
        color = COLORS[e["symbol"]]
        xs = [p[0] for p in e["points"]]
        ys = [p[1] for p in e["points"]]
        fig.add_trace(
            go.Scatter(
                x=xs, y=ys, mode="lines",
                line=dict(color=color, width=2.2),
                hoverinfo="skip", showlegend=False,
            )
        )
        (x1, y1), (x0, y0) = e["points"][-1], e["points"][-2]
        annotations.append(
            dict(
                x=x1, y=y1, ax=x0, ay=y0, xref="x", yref="y", axref="x", ayref="y",
                showarrow=True, arrowhead=3, arrowsize=1.4, arrowwidth=2.2,
                arrowcolor=color, text="",
            )
        )
        lx, ly = e["label_pos"]
        annotations.append(
            dict(
                x=lx, y=ly, xref="x", yref="y", showarrow=False, text=f"<b>{e['symbol']}</b>",
                font=dict(color=color, size=15),
                bgcolor="rgba(11,18,32,0.85)", borderpad=2,
            )
        )

    # ---- start arrow -----------------------------------------------------
    sx, sy = node_position(START_STATE)
    annotations.append(
        dict(
            x=sx - 0.4, y=sy, ax=sx - 1.35, ay=sy, xref="x", yref="y", axref="x", ayref="y",
            showarrow=True, arrowhead=3, arrowsize=1.4, arrowwidth=2.2,
            arrowcolor=COLORS["text"], text="",
        )
    )
    annotations.append(
        dict(x=sx - 1.35, y=sy + 0.3, xref="x", yref="y", showarrow=False,
             text="start", font=dict(color=COLORS["muted"], size=12))
    )

    # ---- rings: accepting (double circle) and current ---------------------
    acc = [s for s in STATES if s in ACCEPTING_STATES]
    fig.add_trace(
        go.Scatter(
            x=[node_position(s)[0] for s in acc], y=[node_position(s)[1] for s in acc],
            mode="markers",
            marker=dict(size=72, color="rgba(0,0,0,0)", line=dict(color="#ffffff", width=2)),
            hoverinfo="skip", showlegend=False,
        )
    )
    if current_state in STATES:
        cx, cy = node_position(current_state)
        fig.add_trace(
            go.Scatter(
                x=[cx], y=[cy], mode="markers",
                marker=dict(size=92, color="rgba(34,211,238,0.12)",
                            line=dict(color=COLORS["current"], width=4)),
                hoverinfo="skip", showlegend=False,
            )
        )
        annotations.append(
            dict(x=cx, y=1.75, xref="x", yref="y", showarrow=False,
                 text="<b>CURRENT STATE</b>", font=dict(color=COLORS["current"], size=11))
        )

    # ---- nodes -----------------------------------------------------------
    fig.add_trace(
        go.Scatter(
            x=[node_position(s)[0] for s in STATES],
            y=[node_position(s)[1] for s in STATES],
            mode="markers+text",
            text=[f"<b>{s}</b>" for s in STATES],
            textfont=dict(color="#ffffff", size=16),
            marker=dict(
                size=58,
                color=[COLORS[STATE_CATEGORY[s]] for s in STATES],
                line=dict(color="#0b1220", width=2),
            ),
            hovertext=[
                f"{s}: {STATE_DESCRIPTIONS[s]}<br>Category: {STATE_CATEGORY[s]}"
                + ("<br>Accepting state" if s in ACCEPTING_STATES else "")
                + ("<br>Initial state" if s == START_STATE else "")
                for s in STATES
            ],
            hoverinfo="text",
            showlegend=False,
        )
    )

    # ---- legend ------------------------------------------------------------
    legend = (
        f"<span style='color:{COLORS['Normal']}'>●</span> Normal   "
        f"<span style='color:{COLORS['Warning']}'>●</span> Warning   "
        f"<span style='color:{COLORS['Suspicious']}'>●</span> Suspicious   "
        f"◎ Accepting state   "
        f"<span style='color:{COLORS['F']}'>━ F</span> failed login   "
        f"<span style='color:{COLORS['S']}'>━ S</span> successful login"
    )
    annotations.append(
        dict(x=0.5, y=-0.03, xref="paper", yref="paper", showarrow=False, text=legend,
             font=dict(color=COLORS["muted"], size=12))
    )

    fig.update_layout(
        height=height,
        margin=dict(l=10, r=10, t=10, b=30),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(visible=False, range=[-1.8, 9.6]),
        yaxis=dict(visible=False, range=[-4.1, 2.2]),
        annotations=annotations,
        hoverlabel=dict(bgcolor="#111a2e", font_color="#e6edf7"),
    )
    return fig
