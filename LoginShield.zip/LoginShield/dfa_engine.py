"""
dfa_engine.py - The Deterministic Finite Automaton behind LoginShield.

Formal model
------------
    M = (Q, Sigma, delta, q0, F)

    Q     = {q0, q1, q2, q3, q4}
    Sigma = {F, S}              F = failed login, S = successful login
    q0    = initial state
    F     = {q4}                accepting (suspicious) state

    delta | F  | S
    ------+----+----
    q0    | q1 | q0
    q1    | q2 | q0
    q2    | q3 | q0
    q3    | q4 | q0
    q4    | q4 | q0

Every detection result in the application is produced by stepping through this
transition table. There is no counter or heuristic anywhere in the project.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, FrozenSet, Iterable, Mapping, Tuple

# --------------------------------------------------------------------------- #
# The LoginShield automaton definition (exact table from the specification)
# --------------------------------------------------------------------------- #
STATES: Tuple[str, ...] = ("q0", "q1", "q2", "q3", "q4")
ALPHABET: Tuple[str, ...] = ("F", "S")
START_STATE: str = "q0"
ACCEPTING_STATES: FrozenSet[str] = frozenset({"q4"})

TRANSITION_TABLE: Dict[str, Dict[str, str]] = {
    "q0": {"F": "q1", "S": "q0"},
    "q1": {"F": "q2", "S": "q0"},
    "q2": {"F": "q3", "S": "q0"},
    "q3": {"F": "q4", "S": "q0"},
    "q4": {"F": "q4", "S": "q0"},
}

STATE_DESCRIPTIONS: Dict[str, str] = {
    "q0": "No consecutive failures",
    "q1": "One consecutive failure",
    "q2": "Two consecutive failures",
    "q3": "Three consecutive failures",
    "q4": "Four or more consecutive failures (suspicious)",
}

# Used only for colouring / labelling in the UI.
STATE_CATEGORY: Dict[str, str] = {
    "q0": "Normal",
    "q1": "Normal",
    "q2": "Warning",
    "q3": "Warning",
    "q4": "Suspicious",
}


# --------------------------------------------------------------------------- #
# Errors and result containers
# --------------------------------------------------------------------------- #
class DFAError(Exception):
    """Base class for DFA related errors."""


class InvalidSymbolError(DFAError):
    """Raised when an input symbol is not in the alphabet."""

    def __init__(self, symbol: str, position: int, alphabet: Iterable[str] = ALPHABET):
        self.symbol = symbol
        self.position = position  # 1-based position in the input
        self.alphabet = tuple(alphabet)
        super().__init__(
            f"Invalid symbol {symbol!r} at position {position}; "
            f"alphabet is {{{', '.join(self.alphabet)}}}"
        )


@dataclass(frozen=True)
class Transition:
    """One application of the transition function delta(previous, symbol) = next."""

    step: int
    symbol: str
    previous_state: str
    next_state: str


@dataclass(frozen=True)
class DFARun:
    """Complete record of running the DFA on one input string."""

    symbols: Tuple[str, ...]
    transitions: Tuple[Transition, ...]
    start_state: str
    final_state: str
    accepted: bool            # is the *final* state accepting?
    visited_accepting: bool   # was an accepting state visited at ANY point?
    alert_steps: Tuple[int, ...]  # steps at which the DFA ENTERED an accepting state

    @property
    def state_path(self) -> Tuple[str, ...]:
        return (self.start_state,) + tuple(t.next_state for t in self.transitions)


# --------------------------------------------------------------------------- #
# Generic DFA implementation
# --------------------------------------------------------------------------- #
class DFA:
    """A complete deterministic finite automaton."""

    def __init__(
        self,
        states: Iterable[str],
        alphabet: Iterable[str],
        transitions: Mapping[str, Mapping[str, str]],
        start_state: str,
        accepting_states: Iterable[str],
    ) -> None:
        self.states = tuple(states)
        self.alphabet = tuple(alphabet)
        self.transitions = {s: dict(transitions[s]) for s in self.states if s in transitions}
        self.start_state = start_state
        self.accepting_states = frozenset(accepting_states)
        self._validate()

    # -- definition checks --------------------------------------------------
    def _validate(self) -> None:
        if self.start_state not in self.states:
            raise DFAError("Start state must belong to Q")
        if not self.accepting_states <= set(self.states):
            raise DFAError("Accepting states must be a subset of Q")
        for state in self.states:
            if state not in self.transitions:
                raise DFAError(f"State {state} has no transitions")
            for symbol in self.alphabet:
                if symbol not in self.transitions[state]:
                    raise DFAError(f"delta({state}, {symbol}) is undefined (DFA must be total)")
                if self.transitions[state][symbol] not in self.states:
                    raise DFAError(f"delta({state}, {symbol}) leads outside Q")

    # -- transition function ------------------------------------------------
    def delta(self, state: str, symbol: str) -> str:
        """The transition function delta: Q x Sigma -> Q."""
        if symbol not in self.alphabet:
            raise InvalidSymbolError(symbol, 0, self.alphabet)
        return self.transitions[state][symbol]

    def is_accepting(self, state: str) -> bool:
        return state in self.accepting_states

    # -- running ------------------------------------------------------------
    def run(self, symbols: Iterable[str]) -> DFARun:
        """
        Process a sequence of symbols from the start state.

        The whole input is validated first, so an invalid symbol raises
        InvalidSymbolError before any state is changed or reported.
        """
        sequence = tuple(symbols)
        for position, symbol in enumerate(sequence, start=1):
            if symbol not in self.alphabet:
                raise InvalidSymbolError(symbol, position, self.alphabet)

        state = self.start_state
        transitions = []
        alert_steps = []
        visited_accepting = self.is_accepting(state)
        for step, symbol in enumerate(sequence, start=1):
            nxt = self.transitions[state][symbol]
            transitions.append(Transition(step, symbol, state, nxt))
            if self.is_accepting(nxt) and not self.is_accepting(state):
                alert_steps.append(step)
            visited_accepting = visited_accepting or self.is_accepting(nxt)
            state = nxt

        return DFARun(
            symbols=sequence,
            transitions=tuple(transitions),
            start_state=self.start_state,
            final_state=state,
            accepted=self.is_accepting(state),
            visited_accepting=visited_accepting,
            alert_steps=tuple(alert_steps),
        )

    def accepts(self, symbols: Iterable[str]) -> bool:
        """Classic language acceptance: does the input END in an accepting state?"""
        return self.run(symbols).accepted

    def contains_pattern(self, symbols: Iterable[str]) -> bool:
        """
        Did the run visit an accepting state at any point?

        This is the 'alert ever occurred' property: it is true exactly for the
        language  Sigma* F F F F Sigma*  (strings containing four consecutive F).
        """
        return self.run(symbols).visited_accepting


def build_loginshield_dfa() -> DFA:
    """Create the exact DFA specified for the LoginShield project."""
    return DFA(STATES, ALPHABET, TRANSITION_TABLE, START_STATE, ACCEPTING_STATES)


# Shared instance used by the whole application.
LOGIN_DFA: DFA = build_loginshield_dfa()
