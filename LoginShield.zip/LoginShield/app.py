"""
LoginShield - DFA-Powered Login Threat Pattern Detection (Streamlit dashboard)

Run with:  streamlit run app.py
"""

from __future__ import annotations

import html
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import analyzer
import csv_handler
import diagram
import test_cases
from dfa_engine import (
    ACCEPTING_STATES,
    ALPHABET,
    LOGIN_DFA,
    START_STATE,
    STATE_CATEGORY,
    STATE_DESCRIPTIONS,
    STATES,
    TRANSITION_TABLE,
)

BASE_DIR = Path(__file__).resolve().parent
SAMPLE_CSV = BASE_DIR / "sample_data" / "login_events.csv"

st.set_page_config(page_title="LoginShield", page_icon="🛡️", layout="wide")


# --------------------------------------------------------------------------- #
# Styling helpers
# --------------------------------------------------------------------------- #
def load_css() -> None:
    css_file = BASE_DIR / "assets" / "style.css"
    try:
        st.markdown(f"<style>{css_file.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)
    except OSError:
        st.warning("assets/style.css could not be loaded; using default styling.")


def metric_card(label: str, value, sub: str = "", tone: str = "blue") -> str:
    return (
        f'<div class="ls-card ls-{tone}">'
        f'<div class="ls-card-label">{html.escape(str(label))}</div>'
        f'<div class="ls-card-value">{html.escape(str(value))}</div>'
        f'<div class="ls-card-sub">{html.escape(str(sub))}</div></div>'
    )


def section(title: str) -> None:
    st.markdown(f'<div class="ls-section">{html.escape(title)}</div>', unsafe_allow_html=True)


def path_html(states) -> str:
    parts = [f'<span class="{s}">{s}</span>' for s in states]
    return '<div class="ls-path">' + " → ".join(parts) + "</div>"


def style_history(df: pd.DataFrame):
    def status_color(val: str) -> str:
        v = str(val)
        if v.startswith("ALERT") or v.startswith("Suspicious"):
            return "background-color: rgba(255,77,79,.22); color: #ff8a8c; font-weight: 600"
        if v.startswith("Warning"):
            return "background-color: rgba(245,165,36,.18); color: #f5a524"
        if v.startswith("Reset"):
            return "background-color: rgba(52,211,153,.16); color: #34d399"
        return "color: #7cc4ff"

    def state_color(val: str) -> str:
        cat = STATE_CATEGORY.get(str(val), "")
        return {
            "Suspicious": "color: #ff6b6d; font-weight: 700",
            "Warning": "color: #f5a524; font-weight: 600",
        }.get(cat, "color: #22d3ee")

    return (
        df.style.map(status_color, subset=["Status"])
        .map(state_color, subset=["Previous State", "Next State"])
    )


def style_lab(df: pd.DataFrame):
    def result_color(val: str) -> str:
        if val == "PASS":
            return "background-color: rgba(52,211,153,.2); color: #34d399; font-weight: 700"
        if val == "FAIL":
            return "background-color: rgba(255,77,79,.25); color: #ff6b6d; font-weight: 700"
        return ""

    return df.style.map(result_color, subset=["Result"])


# --------------------------------------------------------------------------- #
# Session state
# --------------------------------------------------------------------------- #
def init_state() -> None:
    ss = st.session_state
    ss.setdefault("stats", {"analyses": 0, "events": 0, "failed": 0, "success": 0, "suspicious": 0})
    ss.setdefault("active", None)        # last valid AnalysisResult (any source)
    ss.setdefault("manual", None)        # last manual AnalysisResult (valid or invalid)
    ss.setdefault("csv_state", None)     # dict with validation/result/report
    ss.setdefault("lab_results", None)
    ss.setdefault("seq_input", "F F S F F F F")


def record_analysis(result: analyzer.AnalysisResult) -> None:
    """Add a valid analysis to the dashboard counters (called once per button click)."""
    s = st.session_state.stats
    s["analyses"] += 1
    s["events"] += len(result.symbols)
    s["failed"] += result.failed_count
    s["success"] += result.success_count
    s["suspicious"] += result.alert_count
    st.session_state.active = result


def set_example(text: str) -> None:
    st.session_state.seq_input = text


# Button callbacks run BEFORE the script re-executes, so the dashboard (drawn
# first) always reflects the analysis that was just triggered.
def cb_run_manual() -> None:
    result = analyzer.analyze_text(st.session_state.seq_input)
    st.session_state.manual = result
    if result.valid:
        record_analysis(result)


def cb_run_csv() -> None:
    ss = st.session_state
    if ss.get("use_sample") and SAMPLE_CSV.exists():
        source, name = SAMPLE_CSV.read_bytes(), "login_events.csv (sample)"
    elif ss.get("csv_upload") is not None:
        source, name = ss.csv_upload.getvalue(), ss.csv_upload.name
    else:
        return
    validation, result, report = csv_handler.load_and_process(source)
    ss.csv_state = {"name": name, "validation": validation, "result": result, "report": report}
    if result is not None:
        record_analysis(result)


def cb_run_lab() -> None:
    st.session_state.lab_results = test_cases.run_all_cases()


def cb_reset_dashboard() -> None:
    st.session_state.stats = {"analyses": 0, "events": 0, "failed": 0, "success": 0, "suspicious": 0}
    st.session_state.active = None


# --------------------------------------------------------------------------- #
# Reusable result rendering
# --------------------------------------------------------------------------- #
def render_verdict(result: analyzer.AnalysisResult) -> None:
    if not result.valid:
        tone, title, sub = "amber", "INVALID INPUT", result.error
    elif result.pattern_detected:
        tone, title = "red", "SUSPICIOUS LOGIN PATTERN DETECTED."
        sub = f"{result.alert_count} suspicious sequence(s) found · final DFA state: {result.final_state}"
    else:
        tone, title = "green", "NO SUSPICIOUS PATTERN DETECTED."
        sub = f"The accepting state q4 was never reached · final DFA state: {result.final_state}"
    st.markdown(
        f'<div class="ls-banner ls-banner-{tone}"><h3>{html.escape(title)}</h3>'
        f"<p>{html.escape(str(sub))}</p></div>",
        unsafe_allow_html=True,
    )


def render_result(result: analyzer.AnalysisResult, key: str) -> None:
    render_verdict(result)

    if result.valid:
        section("State transitions")
        if result.symbols:
            st.markdown(path_html(result.state_path), unsafe_allow_html=True)
        else:
            st.markdown(path_html([START_STATE]), unsafe_allow_html=True)

        c1, c2, c3, c4 = st.columns(4)
        c1.markdown(
            metric_card("Suspicious pattern occurred", "YES" if result.pattern_detected else "NO",
                        "q4 visited at any step", "red" if result.pattern_detected else "green"),
            unsafe_allow_html=True)
        c2.markdown(
            metric_card("Final DFA state", result.final_state,
                        STATE_DESCRIPTIONS[result.final_state],
                        "red" if result.final_state == "q4" else "cyan"),
            unsafe_allow_html=True)
        c3.markdown(metric_card("Alerts (entries into q4)", result.alert_count, "separate suspicious runs",
                                "red" if result.alert_count else "blue"), unsafe_allow_html=True)
        c4.markdown(metric_card("Events processed", len(result.symbols),
                                f"{result.failed_count} F · {result.success_count} S"),
                    unsafe_allow_html=True)

    section("Explanation")
    st.markdown(f'<div class="ls-explain">{html.escape(result.explanation)}</div>', unsafe_allow_html=True)

    if result.valid:
        section("Transition history")
        if result.history:
            st.dataframe(style_history(analyzer.history_dataframe(result)),
                         hide_index=True, width="stretch")
        else:
            st.caption("No events were processed, so there are no transitions.")

        section("DFA diagram (final state highlighted)")
        st.plotly_chart(diagram.build_figure(result.final_state), width="stretch",
                        key=f"diagram_{key}", config={"displayModeBar": False})


# --------------------------------------------------------------------------- #
# Tabs
# --------------------------------------------------------------------------- #
def tab_dashboard() -> None:
    s = st.session_state.stats
    active = st.session_state.active

    current_state = active.final_state if active else START_STATE
    if s["analyses"] == 0:
        status, tone, sub = "AWAITING DATA", "blue", "Run an analysis to begin"
    elif s["suspicious"] > 0:
        status, tone, sub = "THREAT DETECTED", "red", "Suspicious pattern(s) found"
    else:
        status, tone, sub = "ALL CLEAR", "green", "No suspicious patterns so far"

    r1 = st.columns(3)
    r1[0].markdown(metric_card("Total login events processed", s["events"],
                               f"{s['analyses']} analysis run(s) this session"), unsafe_allow_html=True)
    r1[1].markdown(metric_card("Failed login attempts", s["failed"], "input symbol F", "amber"),
                   unsafe_allow_html=True)
    r1[2].markdown(metric_card("Successful login attempts", s["success"], "input symbol S", "green"),
                   unsafe_allow_html=True)
    r2 = st.columns(3)
    r2[0].markdown(metric_card("Suspicious sequences", s["suspicious"], "entries into accepting state q4",
                               "red" if s["suspicious"] else "blue"), unsafe_allow_html=True)
    r2[1].markdown(metric_card("Current DFA state", current_state, STATE_DESCRIPTIONS[current_state],
                               "red" if current_state == "q4" else "cyan"), unsafe_allow_html=True)
    r2[2].markdown(metric_card("Overall detection status", status, sub, tone), unsafe_allow_html=True)

    if s["analyses"] == 0:
        st.info("No data yet. Open the **Analyzer** or **CSV Upload** tab and run an analysis; "
                "the counters above are updated from every run in this session.")
        return

    left, right = st.columns(2)
    with left:
        section("Login outcomes")
        fig = go.Figure(go.Bar(
            x=["Failed (F)", "Successful (S)"], y=[s["failed"], s["success"]],
            marker_color=["#ff8a65", "#34d399"], text=[s["failed"], s["success"]], textposition="outside"))
        fig.update_layout(height=300, margin=dict(l=10, r=10, t=10, b=10),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font=dict(color="#e6edf7"), yaxis=dict(gridcolor="#223152"))
        st.plotly_chart(fig, width="stretch", key="chart_outcomes", config={"displayModeBar": False})
    with right:
        section("DFA states visited in the latest analysis")
        if active and active.symbols:
            visits = pd.Series(active.state_path[1:]).value_counts().reindex(STATES, fill_value=0)
            colors = [diagram.COLORS[STATE_CATEGORY[q]] for q in STATES]
            fig2 = go.Figure(go.Bar(x=list(STATES), y=visits.values, marker_color=colors,
                                    text=visits.values, textposition="outside"))
            fig2.update_layout(height=300, margin=dict(l=10, r=10, t=10, b=10),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                               font=dict(color="#e6edf7"), yaxis=dict(gridcolor="#223152"))
            st.plotly_chart(fig2, width="stretch", key="chart_states", config={"displayModeBar": False})
        else:
            st.caption("The latest analysis had no events.")

    if active:
        section("Latest analysis")
        render_verdict(active)
        st.markdown(f'<div class="ls-explain">{html.escape(active.explanation)}</div>', unsafe_allow_html=True)

    st.button("Reset dashboard counters", on_click=cb_reset_dashboard, key="reset_dash")


def tab_analyzer() -> None:
    section("Manual login sequence analyzer")
    st.caption("Enter F (failed) and S (successful) logins separated by spaces or commas, e.g. `F F S F F F F`.")

    st.text_input("Login sequence", key="seq_input", placeholder="F F F F")

    ex = st.columns(4)
    ex[0].button("F F F F", on_click=set_example, args=("F F F F",), key="ex1")
    ex[1].button("F F S F F F F", on_click=set_example, args=("F F S F F F F",), key="ex2")
    ex[2].button("S F F S F F", on_click=set_example, args=("S F F S F F",), key="ex3")
    ex[3].button("F F F F S", on_click=set_example, args=("F F F F S",), key="ex4")

    st.button("Run Analysis", type="primary", key="run_manual", on_click=cb_run_manual)

    result = st.session_state.manual
    if result is None:
        st.info("Enter a sequence and press **Run Analysis**.")
        return
    shown = result.raw_input if result.raw_input else "(empty)"
    st.markdown(f"**Analysed input:** `{shown}`")
    render_result(result, key="manual")


def tab_diagram() -> None:
    section("DFA state diagram")
    active = st.session_state.active
    current = START_STATE
    caption = "No analysis yet - showing the initial state. Run an analysis to step through it here."

    if active and active.symbols:
        n = len(active.symbols)
        step = n
        if n > 1:
            step = st.slider("Step through the latest analysis (0 = start)", 0, n, n,
                             key=f"diagram_step_{st.session_state.stats['analyses']}")
        if step == 0:
            current, caption = START_STATE, "Before any input: DFA is in the initial state q0."
        else:
            t = active.run.transitions[step - 1]
            current = t.next_state
            caption = (f"Step {t.step}: read **{t.symbol}** → δ({t.previous_state}, {t.symbol}) = "
                       f"**{t.next_state}** ({STATE_DESCRIPTIONS[t.next_state]}).")
    elif active:
        caption = "The latest analysis was empty, so the DFA stays in q0."

    st.markdown(caption)
    st.plotly_chart(diagram.build_figure(current), width="stretch", key="diagram_main",
                    config={"displayModeBar": False})

    left, right = st.columns(2)
    with left:
        section("Formal definition")
        st.markdown(
            "**M = (Q, Σ, δ, q0, F)**\n\n"
            f"- Q = {{{', '.join(STATES)}}}\n"
            f"- Σ = {{{', '.join(ALPHABET)}}}\n"
            f"- Initial state = {START_STATE}\n"
            f"- Final (accepting) states = {{{', '.join(sorted(ACCEPTING_STATES))}}}")
    with right:
        section("Transition table δ")
        table = pd.DataFrame(
            [{"Current State": q, **{sym: TRANSITION_TABLE[q][sym] for sym in ALPHABET},
              "Meaning": STATE_DESCRIPTIONS[q]} for q in STATES])
        st.dataframe(table, hide_index=True, width="stretch")


def tab_csv() -> None:
    section("CSV upload")
    st.caption("Expected columns: `event_id,event_type` where event_type is F or S. Events are processed in file order.")

    c1, c2 = st.columns([3, 1])
    with c1:
        uploaded = st.file_uploader("Upload login events (CSV)", type=["csv"], key="csv_upload")
    with c2:
        st.write("")
        st.write("")
        if SAMPLE_CSV.exists():
            st.download_button("Download sample CSV", SAMPLE_CSV.read_bytes(),
                               file_name="login_events.csv", mime="text/csv", key="dl_sample")
    use_sample = st.checkbox("Use the bundled sample file instead", value=False, key="use_sample")

    has_source = (use_sample and SAMPLE_CSV.exists()) or uploaded is not None
    st.button("Run CSV Analysis", type="primary", key="run_csv", on_click=cb_run_csv,
              disabled=not has_source)

    state = st.session_state.csv_state
    if state is None:
        st.info("Upload a CSV (or tick the sample option) and press **Run CSV Analysis**.")
        return

    validation, result, report = state["validation"], state["result"], state["report"]
    st.markdown(f"**File:** `{state['name']}`")
    for w in validation.warnings:
        st.warning(w)
    if not validation.valid:
        st.error("Validation failed - the file was not analysed.")
        for e in validation.errors:
            st.markdown(f"- {e}")
        return

    st.success(f"Validation passed - {len(result.symbols)} events processed through the DFA.")
    render_verdict(result)

    a, b, c, d = st.columns(4)
    a.markdown(metric_card("Events", len(result.symbols)), unsafe_allow_html=True)
    b.markdown(metric_card("Failed / Successful", f"{result.failed_count} / {result.success_count}", "", "amber"),
               unsafe_allow_html=True)
    c.markdown(metric_card("Suspicious sequences", result.alert_count, "",
                           "red" if result.alert_count else "green"), unsafe_allow_html=True)
    d.markdown(metric_card("Final state", result.final_state, STATE_DESCRIPTIONS[result.final_state],
                           "red" if result.final_state == "q4" else "cyan"), unsafe_allow_html=True)

    section("State path")
    st.markdown(path_html(result.state_path), unsafe_allow_html=True)
    section("Explanation")
    st.markdown(f'<div class="ls-explain">{html.escape(result.explanation)}</div>', unsafe_allow_html=True)
    section("Analysis report")
    st.dataframe(report, hide_index=True, width="stretch")

    d1, d2 = st.columns(2)
    d1.download_button("Download analysis report (CSV)", csv_handler.report_to_csv(report),
                       file_name="loginshield_report.csv", mime="text/csv", key="dl_report")
    d2.download_button("Download summary (CSV)", csv_handler.summary_to_csv(result),
                       file_name="loginshield_summary.csv", mime="text/csv", key="dl_summary")


def tab_lab() -> None:
    section("Test case laboratory")
    st.caption("Every case runs through the real DFA; results and the pass rate are computed when you press the button.")

    st.button("Run All Tests", type="primary", key="run_lab", on_click=cb_run_lab)

    results = st.session_state.lab_results
    if results is None:
        st.dataframe(test_cases.definitions_dataframe(), hide_index=True, width="stretch")
        st.info("Press **Run All Tests** to execute these cases.")
        return

    pct = test_cases.pass_percentage(results)
    passed = sum(r.passed for r in results)
    c1, c2, c3 = st.columns(3)
    c1.markdown(metric_card("Pass rate", f"{pct:.1f}%", "computed from execution results",
                            "green" if passed == len(results) else "red"), unsafe_allow_html=True)
    c2.markdown(metric_card("Passed", passed, f"of {len(results)} cases", "green"), unsafe_allow_html=True)
    c3.markdown(metric_card("Failed", len(results) - passed, "", "red" if passed != len(results) else "blue"),
                unsafe_allow_html=True)
    st.dataframe(style_lab(test_cases.results_dataframe(results)), hide_index=True, width="stretch")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> None:
    load_css()
    init_state()

    st.markdown(
        '<div class="ls-header"><div class="ls-logo">🛡️</div><div>'
        '<p class="ls-title">Login<span>Shield</span></p>'
        '<p class="ls-subtitle">DFA-Powered Login Threat Pattern Detection</p></div></div>',
        unsafe_allow_html=True,
    )

    tabs = st.tabs(["📊 Dashboard", "🔍 Analyzer", "🧭 DFA Diagram", "📁 CSV Upload", "🧪 Test Lab"])
    with tabs[0]:
        tab_dashboard()
    with tabs[1]:
        tab_analyzer()
    with tabs[2]:
        tab_diagram()
    with tabs[3]:
        tab_csv()
    with tabs[4]:
        tab_lab()


main()
