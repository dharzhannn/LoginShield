"""
csv_handler.py - Validate uploaded login-event CSV files, run them through the
DFA and export the analysis report.

Expected file format::

    event_id,event_type
    1,F
    2,F
    3,S
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple, Union

import pandas as pd

from analyzer import AnalysisResult, analyze_symbols
from dfa_engine import ALPHABET

REQUIRED_COLUMNS = ("event_id", "event_type")
REPORT_COLUMNS = [
    "step",
    "event_id",
    "event_type",
    "previous_state",
    "next_state",
    "status",
    "alert_triggered",
]
MAX_LISTED_ERRORS = 10

Source = Union[str, Path, bytes, io.IOBase]


class CSVValidationError(Exception):
    """Raised when a file cannot be read as CSV at all."""


@dataclass
class ValidationResult:
    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    events: Optional[pd.DataFrame] = None  # cleaned frame (only when valid)


# --------------------------------------------------------------------------- #
# Reading
# --------------------------------------------------------------------------- #
def read_events_csv(source: Source) -> pd.DataFrame:
    """Read a CSV from a path, bytes or file-like object as all-string data."""
    try:
        if isinstance(source, (bytes, bytearray)):
            source = io.BytesIO(bytes(source))
        elif hasattr(source, "getvalue") and not isinstance(source, (str, Path)):
            source = io.BytesIO(source.getvalue())
        return pd.read_csv(
            source,
            dtype=str,
            keep_default_na=False,
            encoding="utf-8-sig",
            skipinitialspace=True,
        )
    except pd.errors.EmptyDataError as exc:
        raise CSVValidationError("The file is empty.") from exc
    except (pd.errors.ParserError, UnicodeDecodeError) as exc:
        raise CSVValidationError(f"The file could not be parsed as CSV: {exc}") from exc


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def _format_rows(rows: List[int]) -> str:
    shown = ", ".join(str(r) for r in rows[:MAX_LISTED_ERRORS])
    extra = len(rows) - MAX_LISTED_ERRORS
    return shown + (f" (and {extra} more)" if extra > 0 else "")


def validate_events(df: pd.DataFrame) -> ValidationResult:
    """
    Check the structure and content of a login-event DataFrame.

    Errors (make the file unusable): missing columns, no data rows, blank or
    invalid event_type values.
    Warnings (file still processed): extra columns, blank/duplicate event_id,
    event_id values that are not ascending.
    """
    errors: List[str] = []
    warnings: List[str] = []

    data = df.copy()
    data.columns = [str(c).strip().lower() for c in data.columns]

    missing = [c for c in REQUIRED_COLUMNS if c not in data.columns]
    if missing:
        errors.append(
            "Missing required column(s): " + ", ".join(missing)
            + ". Expected header: event_id,event_type"
        )
        return ValidationResult(False, errors, warnings)

    extra = [c for c in data.columns if c not in REQUIRED_COLUMNS]
    if extra:
        warnings.append("Ignoring extra column(s): " + ", ".join(extra))

    data = data[list(REQUIRED_COLUMNS)].copy()
    data["event_id"] = data["event_id"].astype(str).str.strip()
    data["event_type"] = data["event_type"].astype(str).str.strip().str.upper()

    if len(data) == 0:
        errors.append("The file has a header but no login events.")
        return ValidationResult(False, errors, warnings)

    # CSV line numbers: header is line 1, first data row is line 2.
    blank_rows = [i + 2 for i in data.index[data["event_type"] == ""]]
    if blank_rows:
        errors.append(f"Blank event_type on line(s): {_format_rows(blank_rows)}")

    bad_mask = (data["event_type"] != "") & ~data["event_type"].isin(ALPHABET)
    if bad_mask.any():
        bad_rows = [i + 2 for i in data.index[bad_mask]]
        bad_vals = sorted(set(data.loc[bad_mask, "event_type"]))
        errors.append(
            f"Invalid event_type value(s) {bad_vals} on line(s): "
            f"{_format_rows(bad_rows)}. Allowed values: F, S"
        )

    blank_ids = [i + 2 for i in data.index[data["event_id"] == ""]]
    if blank_ids:
        warnings.append(f"Blank event_id on line(s): {_format_rows(blank_ids)}")

    non_blank = data[data["event_id"] != ""]
    dupes = non_blank[non_blank["event_id"].duplicated(keep=False)]
    if not dupes.empty:
        warnings.append(
            "Duplicate event_id value(s): " + ", ".join(sorted(set(dupes["event_id"])))
        )

    numeric = pd.to_numeric(non_blank["event_id"], errors="coerce")
    if len(non_blank) > 1 and not numeric.isna().any() and not numeric.is_monotonic_increasing:
        warnings.append(
            "event_id values are not in ascending order; events are processed "
            "in file order."
        )

    if errors:
        return ValidationResult(False, errors, warnings)
    return ValidationResult(True, errors, warnings, data.reset_index(drop=True))


# --------------------------------------------------------------------------- #
# Processing and export
# --------------------------------------------------------------------------- #
def process_events(events: pd.DataFrame) -> Tuple[AnalysisResult, pd.DataFrame]:
    """Run validated events (in file order) through the DFA; build the report."""
    result = analyze_symbols(events["event_type"].tolist(), raw_input="CSV upload")
    report = pd.DataFrame(
        {
            "step": [h["Step"] for h in result.history],
            "event_id": events["event_id"].tolist(),
            "event_type": [h["Input"] for h in result.history],
            "previous_state": [h["Previous State"] for h in result.history],
            "next_state": [h["Next State"] for h in result.history],
            "status": [h["Status"] for h in result.history],
            "alert_triggered": [
                "YES" if h["Step"] in result.run.alert_steps else "NO" for h in result.history
            ],
        },
        columns=REPORT_COLUMNS,
    )
    return result, report


def load_and_process(source: Source):
    """
    Read, validate and process a CSV in one call.

    Returns (validation, result, report); result and report are None when the
    file is invalid.
    """
    try:
        df = read_events_csv(source)
    except CSVValidationError as exc:
        return ValidationResult(False, [str(exc)]), None, None
    validation = validate_events(df)
    if not validation.valid:
        return validation, None, None
    result, report = process_events(validation.events)
    return validation, result, report


def report_to_csv(report: pd.DataFrame) -> bytes:
    """Serialise the detailed report for download."""
    return report.to_csv(index=False).encode("utf-8")


def summary_to_csv(result: AnalysisResult) -> bytes:
    """Serialise a short metric/value summary for download."""
    rows = [
        ("total_events", len(result.symbols)),
        ("failed_logins", result.failed_count),
        ("successful_logins", result.success_count),
        ("suspicious_pattern_occurred", "YES" if result.pattern_detected else "NO"),
        ("suspicious_sequences", result.alert_count),
        ("final_state", result.final_state),
        ("verdict", result.verdict),
        ("explanation", result.explanation),
    ]
    return pd.DataFrame(rows, columns=["metric", "value"]).to_csv(index=False).encode("utf-8")
