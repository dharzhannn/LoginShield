"""
Automated tests for LoginShield.

Run from the project root with either:
    python -m unittest discover -s tests -v
    python -m pytest -v
"""

import io
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import analyzer  # noqa: E402
import csv_handler  # noqa: E402
import diagram  # noqa: E402
import test_cases as lab  # noqa: E402
from dfa_engine import (  # noqa: E402
    ACCEPTING_STATES,
    ALPHABET,
    LOGIN_DFA,
    START_STATE,
    STATES,
    TRANSITION_TABLE,
    DFA,
    DFAError,
    InvalidSymbolError,
)

# The specification's table, written out independently of dfa_engine.
EXPECTED_TABLE = [
    ("q0", "F", "q1"), ("q0", "S", "q0"),
    ("q1", "F", "q2"), ("q1", "S", "q0"),
    ("q2", "F", "q3"), ("q2", "S", "q0"),
    ("q3", "F", "q4"), ("q3", "S", "q0"),
    ("q4", "F", "q4"), ("q4", "S", "q0"),
]


def seq(text):
    return analyzer.parse_sequence(text)


class TestDFADefinition(unittest.TestCase):
    def test_formal_components(self):
        self.assertEqual(STATES, ("q0", "q1", "q2", "q3", "q4"))
        self.assertEqual(ALPHABET, ("F", "S"))
        self.assertEqual(START_STATE, "q0")
        self.assertEqual(ACCEPTING_STATES, frozenset({"q4"}))

    def test_every_transition(self):
        for state, symbol, target in EXPECTED_TABLE:
            with self.subTest(state=state, symbol=symbol):
                self.assertEqual(LOGIN_DFA.delta(state, symbol), target)
                self.assertEqual(TRANSITION_TABLE[state][symbol], target)

    def test_table_is_total(self):
        self.assertEqual(sum(len(v) for v in TRANSITION_TABLE.values()), 10)

    def test_incomplete_dfa_rejected(self):
        with self.assertRaises(DFAError):
            DFA(["a", "b"], ["x"], {"a": {"x": "b"}}, "a", ["b"])


class TestDetection(unittest.TestCase):
    def test_four_consecutive_failures(self):
        run = LOGIN_DFA.run(seq("F F F F"))
        self.assertEqual(run.state_path, ("q0", "q1", "q2", "q3", "q4"))
        self.assertTrue(run.accepted)
        self.assertTrue(run.visited_accepting)
        self.assertEqual(run.alert_steps, (4,))

    def test_success_resets_to_q0(self):
        for prefix in ["F", "F F", "F F F", "F F F F", "F F F F F"]:
            with self.subTest(prefix=prefix):
                self.assertEqual(LOGIN_DFA.run(seq(prefix + " S")).final_state, "q0")

    def test_five_or_more_failures_stay_in_q4(self):
        run = LOGIN_DFA.run(seq("F F F F F F F"))
        self.assertEqual(run.final_state, "q4")
        self.assertEqual(run.state_path[4:], ("q4", "q4", "q4", "q4"))
        self.assertEqual(run.alert_steps, (4,))  # entered q4 only once

    def test_three_failures_not_suspicious(self):
        self.assertFalse(LOGIN_DFA.run(seq("F F F")).visited_accepting)

    def test_pattern_followed_by_success(self):
        r = analyzer.analyze_text("F F F F S")
        self.assertTrue(r.pattern_detected)
        self.assertEqual(r.final_state, "q0")
        self.assertEqual(r.verdict, analyzer.VERDICT_SUSPICIOUS)
        self.assertIn("before the successful login reset", r.explanation)

    def test_success_in_middle_breaks_streak(self):
        r = analyzer.analyze_text("F F S F F")
        self.assertFalse(r.pattern_detected)
        self.assertEqual(r.verdict, analyzer.VERDICT_NONE)
        self.assertEqual(r.final_state, "q2")

    def test_multiple_suspicious_patterns(self):
        r = analyzer.analyze_text("F F F F S F F F F F S F F F F")
        self.assertEqual(r.alert_count, 3)
        self.assertEqual(r.run.alert_steps, (4, 9, 15))
        self.assertEqual(r.final_state, "q4")

    def test_empty_sequence(self):
        r = analyzer.analyze_text("")
        self.assertTrue(r.valid)
        self.assertEqual(r.final_state, "q0")
        self.assertFalse(r.pattern_detected)
        self.assertEqual(r.verdict, analyzer.VERDICT_NONE)
        self.assertEqual(r.history, [])

    def test_language_properties(self):
        """Ever-visited q4 <=> string contains FFFF; final-state acceptance <=> ends in FFFF."""
        import itertools
        for n in range(0, 9):
            for combo in itertools.product("FS", repeat=n):
                s = "".join(combo)
                self.assertEqual(LOGIN_DFA.contains_pattern(combo), "FFFF" in s, s)
                self.assertEqual(LOGIN_DFA.accepts(combo), s.endswith("FFFF"), s)


class TestInvalidInput(unittest.TestCase):
    def test_invalid_symbol_raises(self):
        with self.assertRaises(InvalidSymbolError) as ctx:
            LOGIN_DFA.run(["F", "F", "F", "X"])
        self.assertEqual(ctx.exception.symbol, "X")
        self.assertEqual(ctx.exception.position, 4)

    def test_invalid_symbol_analysis(self):
        r = analyzer.analyze_text("F F F X")
        self.assertFalse(r.valid)
        self.assertEqual(r.verdict, analyzer.VERDICT_INVALID)
        self.assertIsNone(r.final_state)
        self.assertIn("'X'", r.explanation)

    def test_parsing_variants(self):
        self.assertEqual(seq("f f s"), ["F", "F", "S"])
        self.assertEqual(seq("F,F;S"), ["F", "F", "S"])
        self.assertEqual(seq("FFFFS"), ["F", "F", "F", "F", "S"])
        self.assertEqual(seq("   "), [])
        self.assertEqual(analyzer.analyze_text("FFXF").verdict, analyzer.VERDICT_INVALID)


class TestHistory(unittest.TestCase):
    def test_history_rows_match_transitions(self):
        r = analyzer.analyze_text("F F S")
        df = analyzer.history_dataframe(r)
        self.assertEqual(list(df.columns), analyzer.HISTORY_COLUMNS)
        self.assertEqual(df["Previous State"].tolist(), ["q0", "q1", "q2"])
        self.assertEqual(df["Next State"].tolist(), ["q1", "q2", "q0"])
        self.assertEqual(df["Input"].tolist(), ["F", "F", "S"])


class TestCSV(unittest.TestCase):
    def run_csv(self, text):
        return csv_handler.load_and_process(text.encode("utf-8"))

    def test_valid_file_and_report(self):
        text = "event_id,event_type\n1,F\n2,F\n3,S\n4,F\n5,F\n6,F\n7,F\n"
        validation, result, report = self.run_csv(text)
        self.assertTrue(validation.valid)
        self.assertTrue(result.pattern_detected)
        self.assertEqual(result.final_state, "q4")
        self.assertEqual(list(report.columns), csv_handler.REPORT_COLUMNS)
        self.assertEqual(report["alert_triggered"].tolist().count("YES"), 1)
        self.assertEqual(report["next_state"].tolist(),
                         ["q1", "q2", "q0", "q1", "q2", "q3", "q4"])
        self.assertTrue(csv_handler.report_to_csv(report).startswith(b"step,event_id"))
        self.assertIn(b"suspicious_pattern_occurred,YES", csv_handler.summary_to_csv(result))

    def test_missing_column(self):
        validation, result, _ = self.run_csv("id,type\n1,F\n")
        self.assertFalse(validation.valid)
        self.assertIsNone(result)
        self.assertIn("Missing required column", validation.errors[0])

    def test_invalid_symbol_in_file(self):
        validation, _, _ = self.run_csv("event_id,event_type\n1,F\n2,X\n3,S\n")
        self.assertFalse(validation.valid)
        self.assertIn("line(s): 3", validation.errors[0])

    def test_blank_event_type(self):
        validation, _, _ = self.run_csv("event_id,event_type\n1,F\n2,\n")
        self.assertFalse(validation.valid)
        self.assertIn("Blank event_type", validation.errors[0])

    def test_empty_file_and_header_only(self):
        validation, _, _ = self.run_csv("")
        self.assertFalse(validation.valid)
        validation, _, _ = self.run_csv("event_id,event_type\n")
        self.assertFalse(validation.valid)
        self.assertIn("no login events", validation.errors[0])

    def test_case_whitespace_and_bom_tolerated(self):
        data = "﻿Event_ID , Event_Type\n1, f \n2,s\n".encode("utf-8")
        validation, result, _ = csv_handler.load_and_process(data)
        self.assertTrue(validation.valid, validation.errors)
        self.assertEqual(result.symbols, ["F", "S"])

    def test_warnings_for_extra_columns_and_duplicates(self):
        validation, _, _ = self.run_csv("event_id,event_type,user\n1,F,a\n1,S,b\n")
        self.assertTrue(validation.valid)
        self.assertEqual(len(validation.warnings), 2)

    def test_file_like_object(self):
        validation, result, _ = csv_handler.load_and_process(io.BytesIO(b"event_id,event_type\n1,F\n"))
        self.assertTrue(validation.valid)
        self.assertEqual(result.final_state, "q1")

    def test_bundled_sample_file(self):
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "sample_data", "login_events.csv")
        validation, result, _ = csv_handler.load_and_process(path)
        self.assertTrue(validation.valid)
        self.assertTrue(result.pattern_detected)


class TestLab(unittest.TestCase):
    def test_all_lab_cases_pass(self):
        results = lab.run_all_cases()
        self.assertEqual(len(results), 8)
        for r in results:
            self.assertTrue(r.passed, f"{r.case.name}: {r.actual}")
        self.assertEqual(lab.pass_percentage(results), 100.0)

    def test_pass_percentage_is_computed_not_hardcoded(self):
        bad = lab.LabCase(99, "wrong on purpose", "F F F F", analyzer.VERDICT_NONE)
        results = lab.run_all_cases(lab.LAB_CASES[:3] + [bad])
        self.assertEqual(lab.pass_percentage(results), 75.0)
        self.assertEqual(lab.results_dataframe(results)["Result"].tolist().count("FAIL"), 1)
        self.assertEqual(lab.pass_percentage([]), 0.0)


class TestDiagram(unittest.TestCase):
    def test_diagram_edges_match_transition_table(self):
        self.assertEqual(diagram.edge_set(), set(EXPECTED_TABLE))
        self.assertEqual(len(diagram.compute_edges()), 10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
