"""
analyzer.py - Sequence analysis, transition history and explanations.

All detection decisions come from dfa_engine.LOGIN_DFA. This module only parses
text, packages the DFA run into a friendly result and writes explanations.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, List, Optional

import pandas as pd

from dfa_engine import (
    ALPHABET,
    LOGIN_DFA,
    STATE_CATEGORY,
    STATE_DESCRIPTIONS,
    DFARun,
    InvalidSymbolError,
)

VERDICT_SUSPICIOUS = "SUSPICIOUS"
VERDICT_NONE = "NO PATTERN"
VERDICT_INVALID = "INVALID INPUT"

HISTORY_COLUMNS = ["Step", "Input", "Previous State", "Next State", "Status"]


@dataclass
class AnalysisResult:
    raw_input: str
    symbols: List[str]
    valid: bool
    verdict: str
    explanation: str
    run: Optional[DFARun] = None
    error: Optional[str] = None
    history: List[dict] = field(default_factory=list)

    # -- convenience accessors (None-safe for invalid input) ---------------
    @property
    def final_state(self) -> Optional[str]:
        return self.run.final_state if self.run else None

    @property
    def pattern_detected(self) -> bool:
        return bool(self.run and self.run.visited_accepting)

    @property
    def alert_count(self) -> int:
        return len(self.run.alert_steps) if self.run else 0

    @property
    def state_path(self) -> List[str]:
        return list(self.run.state_path) if self.run else []

    @property
    def failed_count(self) -> int:
        return self.symbols.count("F") if self.valid else 0

    @property
    def success_count(self) -> int:
        return self.symbols.count("S") if self.valid else 0


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #
def parse_sequence(text: str) -> List[str]:
    """
    Turn user text into a list of tokens.

    Accepts spaces, commas or semicolons as separators, is case-insensitive,
    and also accepts compact strings such as "FFFFS" (expanded to F F F F S).
    Anything else is kept as-is so the DFA can reject it as an invalid symbol.
    """
    if text is None:
        return []
    tokens: List[str] = []
    for raw in re.split(r"[\s,;]+", text.strip()):
        if not raw:
            continue
        token = raw.upper()
        if len(token) > 1 and all(ch in ALPHABET for ch in token):
            tokens.extend(token)
        else:
            tokens.append(token)
    return tokens


# --------------------------------------------------------------------------- #
# Explanations
# --------------------------------------------------------------------------- #
def path_string(states: Iterable[str]) -> str:
    return " → ".join(states)


def build_explanation(run: DFARun) -> str:
    final = run.final_state
    path = path_string(run.state_path)

    if not run.symbols:
        return (
            "The sequence is empty, so no login events were processed. The DFA "
            "remains in its initial state q0 (no consecutive failures) and the "
            "accepting state q4 was never reached."
        )

    if run.visited_accepting:
        first = run.alert_steps[0] if run.alert_steps else 0
        parts = [
            "Four or more consecutive failed login attempts were detected. "
            f"The DFA path was {path}, entering the accepting state q4 at "
            f"step {first}."
        ]
        if len(run.alert_steps) > 1:
            steps = ", ".join(str(s) for s in run.alert_steps)
            parts.append(
                f"The pattern occurred {len(run.alert_steps)} separate times "
                f"(entered q4 at steps {steps}); each successful login reset "
                "the DFA before the next run of failures."
            )
        if final == "q4":
            parts.append(
                "The sequence ends in q4, so the current DFA state is still "
                "the suspicious state."
            )
        else:
            parts.append(
                "The suspicious pattern was detected before the successful "
                f"login reset the current DFA state, so the final state is "
                f"{final} ({STATE_DESCRIPTIONS[final].lower()}) even though "
                "an alert occurred earlier in the sequence."
            )
        return " ".join(parts)

    deepest = max(run.state_path, key=lambda s: int(s[1:]))
    streak = int(deepest[1:])
    parts = [
        "No suspicious pattern was found. The accepting state q4 was never "
        f"reached; the DFA path was {path}."
    ]
    if streak == 0:
        parts.append("There were no failed logins in a row at any point.")
    else:
        word = "failure" if streak == 1 else "failures"
        parts.append(
            f"The longest run of consecutive failures was {streak} {word} "
            f"(state {deepest}), which is below the threshold of four."
        )
    parts.append(
        f"The final state is {final} ({STATE_DESCRIPTIONS[final].lower()}), "
        "which is not the accepting state q4."
    )
    return " ".join(parts)


def _step_status(run: DFARun, t) -> str:
    """Human-readable status for one transition."""
    if t.step in run.alert_steps:
        return "ALERT - suspicious state reached"
    if t.next_state == "q4":
        return "Suspicious - still in q4"
    if t.symbol == "S" and t.previous_state != "q0":
        return f"Reset to q0 (was {STATE_CATEGORY[t.previous_state].lower()})"
    return STATE_CATEGORY[t.next_state]


def build_history(run: DFARun) -> List[dict]:
    return [
        {
            "Step": t.step,
            "Input": t.symbol,
            "Previous State": t.previous_state,
            "Next State": t.next_state,
            "Status": _step_status(run, t),
        }
        for t in run.transitions
    ]


# --------------------------------------------------------------------------- #
# Public analysis API
# --------------------------------------------------------------------------- #
def analyze_symbols(symbols: Iterable[str], raw_input: str = "") -> AnalysisResult:
    """Run a list of symbols through the DFA and package the result."""
    tokens = list(symbols)
    try:
        run = LOGIN_DFA.run(tokens)
    except InvalidSymbolError as exc:
        return AnalysisResult(
            raw_input=raw_input or " ".join(tokens),
            symbols=tokens,
            valid=False,
            verdict=VERDICT_INVALID,
            error=str(exc),
            explanation=(
                f"Invalid input: symbol '{exc.symbol}' at position "
                f"{exc.position} is not in the alphabet Σ = {{F, S}}. The DFA "
                "only reads F (failed login) and S (successful login), so the "
                "sequence was rejected and no state transitions were performed."
            ),
        )

    verdict = VERDICT_SUSPICIOUS if run.visited_accepting else VERDICT_NONE
    return AnalysisResult(
        raw_input=raw_input or " ".join(tokens),
        symbols=tokens,
        valid=True,
        verdict=verdict,
        explanation=build_explanation(run),
        run=run,
        history=build_history(run),
    )


def analyze_text(text: str) -> AnalysisResult:
    """Parse free text such as 'F F S F F F F' and analyse it."""
    return analyze_symbols(parse_sequence(text), raw_input=(text or "").strip())


def history_dataframe(result: AnalysisResult) -> pd.DataFrame:
    return pd.DataFrame(result.history, columns=HISTORY_COLUMNS)
